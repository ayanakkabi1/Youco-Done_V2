<?php
namespace App\Http\Controllers;
use App\Models\Restaurant;
use App\Models\Reservation;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class ReservationController extends Controller {
    use AuthorizesRequests;
    public function reservationbyrestaurant($id)
    {
        $restaurant=Restaurant::findOrFail($id);
        $reservations=$restaurant->reservations;
        return view('admin.reservation.index', compact('restaurant','reservations'));
    }
    public function show(Reservation $reservation)
    {
    $this->authorize('view', $reservation); 
    return view('reservations.show', compact('reservation'));
    }
}